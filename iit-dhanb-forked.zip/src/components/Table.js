import "./style.css";
import { Link } from "react-router-dom";

const data = [
  { title: "Fall Fest", date: "Friday, December 18, 2020" },
  {
    title: "iview Interview Prep Challenge",
    date: "Thursday, August 13, 2020"
  },
  { title: "ACM Interview Bootcamp", date: "Wednesday, August 5, 2020" },
  { title: "How I Got a Job at Facebook", date: "Saturday, July 18, 2020" },
  { title: "Placement Preparation", date: "Tuesday, July 14, 2020" },
  { title: "How I Got a Job at Google", date: "Saturday, July 11, 2020" },
  { title: "ACM League of Code", date: "Friday, July 10, 2020" },
  {
    title: "Competition Programming Live Session",
    date: "Monday, July 6, 2020"
  },
  { title: "FAANG Webinar : Anjali Viramgama", date: "Saturday, July 4, 2020" },
  {
    title: "Roadmap to Artificial Intelligence",
    date: "Tuesday, June 30, 2020"
  },
  {
    title: "Webinar by Mr. Vijay Pravin Mahajan",
    date: "Friday, June 26, 2020"
  },
  {
    title: "Online Workshop on Interview Questions for FAANG Companies",
    date: "Sunday, June 21, 2020"
  },
  {
    title: "Demystifying AI, ML and Data Science",
    date: "Sunday, June 7, 2020"
  },
  { title: "Competitive Programming", date: "Wednesday, May 27, 2020" },
  { title: "AI and Data Science Workshop", date: "Sunday, October 20, 2019" },
  { title: "EArth", date: "Saturday, October 19, 2019" },
  { title: "Build A Bit", date: "Saturday, October 19, 2019" },
  { title: "CODE - IT", date: "Monday, September 30, 2019" },
  {
    title: "Workshop on Introduction to Competitive Programming",
    date: "Wednesday, September 4, 2019"
  },
  { title: "PowerPuff Coders", date: "Tuesday, April 30, 2019" },
  { title: "ACM League of Code", date: "Monday, April 29, 2019" }
];

export default function Table() {
  return (
    <div className="container">
      <h1 className="headingStyle">All Events</h1>
      <table className="rwd-table">
        <tbody>
          <tr>
            <th>Title</th>
            <th>Date</th>
          </tr>
          {data.map((val, key) => {
            return (
              <tr key={key}>
                <Link to="">
                  <td>{val.title}</td>
                </Link>
                <td>{val.date}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
