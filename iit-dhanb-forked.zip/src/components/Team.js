import "./TeamStyle.css";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { Link } from "react-router-dom";
import { FaLinkedin, FaEnvelope } from "react-icons/fa";
import ProfileDemo from "../assets/Profile-demo.png";

export default function Team() {
  return (
    <>
      <Navbar />
      <div className="contain">
        <h1>Our Team</h1>

        <div className="main">
          <ul className="cards">
            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>

            <li className="cards_item">
              <div className="card" tabindex="0">
                <div className="card_image">
                  <img src={ProfileDemo} alt="Profile" />
                </div>
                <div className="card_content">
                  <div className="card_text">
                    <h1>Rajendra Pamula</h1>
                    <p>FACULTY SPONSOR</p>
                    <div className="footer-social-icon">
                      <Link to={`mailto:acm.ism@gmail.com`}>
                        <FaEnvelope />
                      </Link>
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </li>
          </ul>
        </div>
      </div>
      <Footer />
    </>
  );
}
