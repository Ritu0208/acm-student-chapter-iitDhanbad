export const MenuItems = [
  {
    title: "Home",
    url: "/",
    cName: "nav-links"
  },
  {
    title: "Events",
    url: "/events",
    cName: "nav-links"
  },
  {
    title: "Achievements",
    url: "/achievements",
    cName: "nav-links"
  },
  {
    title: "Past Sponsors",
    url: "/pastSponsors",
    cName: "nav-links"
  },
  {
    title: "Team",
    url: "/team",
    cName: "nav-links"
  },
  {
    title: "Contact Us",
    url: "/contact",
    cName: "nav-links"
  }
];
