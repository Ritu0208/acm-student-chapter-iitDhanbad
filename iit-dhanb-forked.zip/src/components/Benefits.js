import "./BenefitStyle.css";

export default function Benefits(props) {
  return (
    <>
      <div className={props.cName}>
        <img alt="HeroImg" src={props.img} />
      </div>
    </>
  );
}
