import "./FooterStyle.css";
import { Link } from "react-router-dom";
import Logo1 from "../assets/logo1.jpg";
import Logo2 from "../assets/logo2.jpg";
import {
  FaFacebookF,
  FaLinkedin,
  FaYoutube,
  FaEnvelope,
  FaHeart
} from "react-icons/fa";

export default function Footer() {
  return (
    <div className="footer-section">
      <div className="container">
        <div className="footer-content pt-5 pb-5">
          <div className="row">
            <div className="col-xl-4 col-lg-4 mb-50">
              <div className="footer-widget">
                <div className="footer-logo">
                  <Link to="/">
                    <img src={Logo2} className="img-fluid" alt="logo" />
                  </Link>
                  <Link to="https://www.iitism.ac.in/">
                    <img src={Logo1} className="img-fluid" alt="logo" />
                  </Link>
                </div>
                <div className="footer-text">
                  <p>ACM Student Chapter </p>
                  <p>IIT (ISM) Dhanbad</p>
                </div>
              </div>
            </div>
            <div className="col-xl-4 col-lg-4 col-md-6 mb-30">
              <div className="footer-widget">
                <div className="footer-widget-heading">
                  <h3>Location</h3>
                </div>
                <p>
                  Department of Computer Science and Engineering, IIT (ISM)
                  Dhanbad, India - 826004
                </p>
              </div>
            </div>
            <div className="col-xl-4 col-lg-4 col-md-6 mb-50">
              <div className="footer-widget">
                <div className="footer-widget-heading">
                  <h3>Get In Touch</h3>
                </div>
                <div className="footer-social-icon">
                  <Link to={`mailto:acm.ism@gmail.com`}>
                    <FaEnvelope />
                  </Link>
                  <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                    <FaLinkedin />
                  </Link>
                  <Link to="https://www.facebook.com/acm.iitismdhn">
                    <FaFacebookF />
                  </Link>
                  <Link to="https://www.youtube.com/channel/UCaXEPdTHm08sxKlTJjRVxJA">
                    <FaYoutube />
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="copyright-area">
        <div className="container">
          <div className="copyright-text">
            <div>
              Made with <FaHeart /> by ACM-IIT(ISM) Dhanbad
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
