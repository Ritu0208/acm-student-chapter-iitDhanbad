import "./AboutStyle.css";
import About1 from "../assets/about1.jpg";
import About2 from "../assets/about2.jpg";

export default function AboutInstitution() {
  return (
    <>
      <div class="we-are-block">
        <h2 className="heading">ABOUT INSTITUTION</h2>
        <div id="history-section">
          <div class="history-image">
            <img src={About1} width="480" height="480" alt="institution" />
          </div>

          <div class="history-info">
            <p>
              IIT(ISM) Dhanbad is one of the oldest institutions in India
              established in the year 1926. It was established on the lines of
              Royal School of Mines-London under the name Indian School of Mines
              located in Dhanbad, Coal Capital of India. Indian School of Mines
              started by offering Mining Engineering, Applied Geology, Applied
              Physics, Applied Chemistry, Applied Mathematics and gradually
              started offering core courses of Computer Science, Electrical,
              Electronics etc expanding from Earth Sciences to technical side.
              Later in the year 2016, Indian School of Mines was awarded the tag
              of an IIT and renamed as Indian Institute of Technology(Indian
              School of Mines), Dhanbad. With a clear intent of the institution
              to improve the amount of research and projects in the institution,
              it has invested most of it's resources dedicated towards the
              projects and research.
            </p>
          </div>
        </div>
        <h2 className="heading">ABOUT ACM</h2>
        <div id="about-us-section">
          <div class="about-us-image">
            <img src={About2} width="480" height="480" alt="ACM" />
          </div>

          <div class="about-us-info">
            <p>
              IIT (ISM) Dhanbad ACM Student Chapter was established in 2011
              under the aegis of Department of Computer Science and Engineering,
              IIT(ISM) Dhanbad. The chapter aims at serving as a dynamic hub of
              activites for the computing fraternity of IIT(ISM) Dhanbad, where
              enthusiasts meet, interact and learn from each other. The chapter
              organizes various events which includes hackathons, technical
              workshops, talks by renowned speakers and coding competitions
              catering to 1500+ enthusiasts. With over 1400+ paid members, our
              chapter is one of the biggest student chapters in India.
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
