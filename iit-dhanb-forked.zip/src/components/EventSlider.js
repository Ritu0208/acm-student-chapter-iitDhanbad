import "./EventSlider.css";
import { Link } from "react-router-dom";
import fallfest from "../assets/fallfest.jpg";
import iview from "../assets/iview.png";
import acmInterview from "../assets/acminterviewbootcamp.jpg";
import jobatfacebook from "../assets/jobatfacebook.jpg";
import placementpreparation from "../assets/placementpreparation.jpg";
import jobatgoogle from "../assets/jobatgoogle.jpg";
// import Button from "../components/Button";

export default function EventSlider(props) {
  return (
    <div className="teamWrapper">
      <div className="container">
        <h1 align="center">{props.sectionName}</h1>
        <div className="teamGrid">
          <Link to="/">
            <div className="colmun">
              <div className="teamcol">
                <div className="teamcolinner">
                  <div className="avatar">
                    <img src={fallfest} alt="Member" />
                  </div>

                  <div className="member-name">
                    <div align="center"> Fall Fest </div>
                  </div>
                  <div className="member-info">
                    <div align="center">Friday, December 18, 2020</div>
                  </div>
                  <div className="member-details">
                    <p align="center">Details</p>
                  </div>
                </div>
              </div>
            </div>
          </Link>

          <Link to="/">
            <div className="colmun">
              <div className="teamcol">
                <div className="teamcolinner">
                  <div className="avatar">
                    <img src={iview} alt="Member" />
                  </div>

                  <div className="member-name">
                    <div align="center">iview Interview Prep Challenge</div>
                  </div>
                  <div className="member-info">
                    <div align="center">Thursday, August 13, 2020</div>
                  </div>
                  <div className="member-details">
                    <p align="center">Details</p>
                  </div>
                </div>
              </div>
            </div>
          </Link>

          <Link to="/">
            <div className="colmun">
              <div className="teamcol">
                <div className="teamcolinner">
                  <div className="avatar">
                    <img src={acmInterview} alt="Member" />
                  </div>

                  <div className="member-name">
                    <div align="center">ACM Interview Bootcamp</div>
                  </div>
                  <div className="member-info">
                    <div align="center">Wednesday, August 5, 2020</div>
                  </div>
                  <div className="member-details">
                    <p align="center">Details</p>
                  </div>
                </div>
              </div>
            </div>
          </Link>

          <Link to="/">
            <div className="colmun">
              <div className="teamcol">
                <div className="teamcolinner">
                  <div className="avatar">
                    <img src={jobatfacebook} alt="Member" />
                  </div>

                  <div className="member-name">
                    <div align="center">How I g0t a Job at Facebook</div>
                  </div>
                  <div className="member-info">
                    <div align="center">Saturday, July 18, 2020</div>
                  </div>
                  <div className="member-details">
                    <p align="center">Details</p>
                  </div>
                </div>
              </div>
            </div>
          </Link>

          <Link to="/">
            <div className="colmun">
              <div className="teamcol">
                <div className="teamcolinner">
                  <div className="avatar">
                    <img src={placementpreparation} alt="Member" />
                  </div>

                  <div className="member-name">
                    <div align="center">Placement Preparation</div>
                  </div>
                  <div className="member-info">
                    <div align="center">Thursday, July 14, 2020</div>
                  </div>
                  <div className="member-details">
                    <p align="center">Details</p>
                  </div>
                </div>
              </div>
            </div>
          </Link>

          <Link to="/">
            <div className="colmun">
              <div className="teamcol">
                <div className="teamcolinner">
                  <div className="avatar">
                    <img src={jobatgoogle} alt="Member" />
                  </div>

                  <div className="member-name">
                    <div align="center">How I Got a Job at Google</div>
                  </div>
                  <div className="member-info">
                    <div align="center">Saturday, July 11, 2020</div>
                  </div>
                  <div className="member-details">
                    <p align="center">Details</p>
                  </div>
                </div>
              </div>
            </div>
          </Link>
        </div>

        {/* <Routes>
          <Route path="/events" element={<Events />} />
        </Routes> */}
      </div>
    </div>
  );
}
