import { Component } from "react";
import Logo from "../assets/logo2.jpg";
import { MenuItems } from "./MenuItems";
import { NavLink } from "react-router-dom";
import { FaBars } from "react-icons/fa";
import "./style.css";

class Navbar extends Component {
  state = { clicked: false };
  handleClick = () => {
    this.setState({ clicked: !this.state.clicked });
  };
  render() {
    return (
      <nav className="NavbarItems">
        <img src={Logo} alt="Logo" className="navbar-logo" />

        <div className="menu-icons" onClick={this.handleClick}>
          <FaBars
            className={this.state.clicked ? "fas fa-times" : "fas fa-bars"}
          />
        </div>

        <ul className={this.state.clicked ? "nav-menu active" : "nav-menu"}>
          {MenuItems.map((items, index) => {
            return (
              <li key={index}>
                <NavLink className={items.cName} to={items.url}>
                  {items.title}
                </NavLink>
              </li>
            );
          })}
        </ul>
      </nav>
    );
  }
}
export default Navbar;
