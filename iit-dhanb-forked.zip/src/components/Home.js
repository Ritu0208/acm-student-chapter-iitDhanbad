import React from "react";
import Navbar from "../components/Navbar";
import Hero from "../components/Hero";
import HeroImg from "../assets/hero-bg.jpg";
import AboutInstitution from "../components/AboutInstitution";
import Benefits from "../components/Benefits";
import BenefitsImg from "../assets/benefitsofacmmembership.jpg";
import Footer from "../components/Footer";
import { Link } from "react-router-dom";
import EventSlider from "../components/EventSlider";

export default function Home() {
  return (
    <>
      <Navbar />
      <Hero cName="hero" img={HeroImg} />
      <AboutInstitution />
      <Benefits cName="benefitStyle" img={BenefitsImg} />
      <Link
        className="customButton"
        to="https://docs.google.com/forms/d/e/1FAIpQLSdjQm1JvXpW5DXdCbBK6iXGdqIRDzkQVXs9L1fTTSlUFam_rA/closedform"
      >
        JOIN NOW
      </Link>
      <EventSlider sectionName="Events" />
      <Link className="customButton" to="/events">
        Explore All
      </Link>
      <Footer />
    </>
  );
}
