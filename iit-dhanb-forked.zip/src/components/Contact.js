import "./ContactStyle.css";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { Link } from "react-router-dom";
import {
  FaFacebookF,
  FaLinkedin,
  FaYoutube,
  FaInstagram
} from "react-icons/fa";

export default function Contact() {
  const locationCoordinates = [23.8100428, 86.4425328];

  const mapStyle = {
    height: "400px",
    width: "100%"
  };

  const customIcon = new L.Icon({
    iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
    iconSize: [32, 32] // adjust the size as needed
  });

  return (
    <>
      <Navbar />
      <div className="contain">
        <h1>Contact Us</h1>

        <div className="contact_us">
          <div className="container">
            <div className="row">
              <div className="col-md-10 offset-md-1">
                <div className="contact_inner">
                  <div className="row">
                    <div className="col-md-10">
                      <div className="contact_form_inner">
                        <div className="contact_field">
                          <h3>Write to us:</h3>

                          <input
                            type="text"
                            className="form-control form-group"
                            placeholder="Name"
                          />
                          <input
                            type="text"
                            className="form-control form-group"
                            placeholder="Email"
                          />
                          <input
                            type="text"
                            className="form-control form-group"
                            placeholder="Subject"
                          />
                          <textarea
                            className="form-control form-group"
                            placeholder="Message"
                          ></textarea>
                          <button className="contact_form_submit">Send</button>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="contact_info_sec">
                    <h4>Reach us at :</h4>
                    <div className="d-flex info_single align-items-center">
                      <Link to="/">
                        <FaInstagram />
                        <span>@acm_iitism</span>
                      </Link>
                    </div>
                    <div className="d-flex info_single align-items-center">
                      <Link to="https://www.linkedin.com/company/acm-student-chapter-iit-ism-dhanbad/">
                        <FaLinkedin />
                        <span>@acm.iitism</span>
                      </Link>
                    </div>
                    <div className="d-flex info_single align-items-center">
                      <Link to="https://www.facebook.com/acm.iitismdhn">
                        <FaFacebookF />
                        <span>@acm.iitismdhn</span>
                      </Link>
                    </div>
                    <div className="d-flex info_single align-items-center">
                      <Link to="https://www.youtube.com/channel/UCaXEPdTHm08sxKlTJjRVxJA">
                        <FaYoutube />
                        <span>@acmiitdhn</span>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="map_sec">
          <div className="container">
            <div className="row">
              <div className="col-md-10 offset-md-1">
                <div className="map_inner">
                  <h4>Find Us on Google Map</h4>

                  <div className="map_bind">
                    <MapContainer
                      center={locationCoordinates}
                      zoom={13}
                      style={mapStyle}
                    >
                      <TileLayer
                        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      />
                      <Marker position={locationCoordinates} icon={customIcon}>
                        <Popup>
                          Indian School of Mines (ISM), Dhanbad - 826004,
                          Jharkhand, India
                        </Popup>
                      </Marker>
                    </MapContainer>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
