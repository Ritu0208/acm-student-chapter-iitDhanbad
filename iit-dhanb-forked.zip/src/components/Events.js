import React from "react";
import Navbar from "../components/Navbar";
import EventSlider from "../components/EventSlider";
import Table from "../components/Table";
import Footer from "../components/Footer";

export default function Events() {
  return (
    <>
      <Navbar />
      <EventSlider sectionName="Recent Events" />
      <Table />
      <Footer />
    </>
  );
}
