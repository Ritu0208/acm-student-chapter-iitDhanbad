import "./PastSponsorsStyle.css";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { Link } from "react-router-dom";
import Samsung from "../assets/samsung.png";
import TechGig from "../assets/TechGig.png";
import GitHub from "../assets/GitHub.png";
import CodeChef from "../assets/codechef.png";
import CodingNinja from "../assets/coding-ninjas.jpg";
import Walmart from "../assets/walmart.jpg";
import Vedanta from "../assets/vedanta.png";
import Teqip from "../assets/teqip.png";
import Mozilla from "../assets/mozilla.png";
import GeeksForGeeks from "../assets/geeks-for-geeks.png";
import Foxmula from "../assets/foxmula.jpeg";
import HackerRank from "../assets/hackerrank.png";
import CodingBlock from "../assets/coding-blocks.jpg";
import Skillenza from "../assets/skillenza.png";
import Devfolio from "../assets/devfolio.png";

export default function PastSponsors() {
  return (
    <>
      <Navbar />
      <div className="contain">
        <h1>Past Sponsors</h1>
        <div className="main-container">
          <div>
            <Link to="https://www.samsung.com/in/">
              <img src={Samsung} alt="Samsung" />{" "}
            </Link>
          </div>

          <div>
            <Link to="http://www.walmart.com/">
              <img src={Walmart} alt="Walmart" />
            </Link>
          </div>

          <div>
            <Link to="https://www.mozilla.org/en-US/">
              <img src={Mozilla} alt="Mozilla" />
            </Link>
          </div>

          <div>
            <Link to="https://github.com/">
              <img src={GitHub} alt="GitHub" />
            </Link>
          </div>

          <div>
            <Link to="https://www.codechef.com/">
              <img src={CodeChef} alt="CodeChef" />
            </Link>
          </div>

          <div>
            <Link to="https://www.geeksforgeeks.org/">
              <img src={GeeksForGeeks} alt="Geeks For Geeks" />
            </Link>
          </div>

          <div>
            <Link to="https://www.hackerrank.com/">
              <img src={HackerRank} alt="Hacker Rank" />
            </Link>
          </div>

          <div>
            <Link to="https://codingblocks.com/">
              <img src={CodingBlock} alt="Coding Block" />
            </Link>
          </div>

          <div>
            <Link to="https://www.codingninjas.com/">
              <img src={CodingNinja} alt="Coding Ninja" />
            </Link>
          </div>

          <div>
            <Link to="https://skillenza.com/">
              <img src={Skillenza} alt="Skillenza" />
            </Link>
          </div>

          <div>
            <Link to="https://www.vedantalimited.com/Pages/Home.aspx">
              <img src={Vedanta} alt="Vedanta" />
            </Link>
          </div>

          <div>
            <Link to="https://devfolio.co/">
              <img src={Devfolio} alt="Devfolio" />
            </Link>
          </div>

          <div>
            <Link to="https://foxmula.com/">
              <img src={Foxmula} alt="Foxmula" />
            </Link>
          </div>

          <div>
            <Link to="https://www.teqip.in/">
              <img src={Teqip} alt="Teqip" />
            </Link>
          </div>

          <div>
            <Link to="https://www.techgig.com/">
              <img src={TechGig} alt="TechGig" />
            </Link>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
