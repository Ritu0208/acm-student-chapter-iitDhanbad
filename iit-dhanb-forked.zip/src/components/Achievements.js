import "./AchievementsStyle.css";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import Achievement from "../assets/achievments.png";
import AchievementFlipkart from "../assets/achievments-flipkart.jpg";
import AchievementGoogle from "../assets/achivement- google.png";

export default function Achievements() {
  return (
    <>
      <Navbar />
      <div className="contain">
        <h1>Achievements</h1>
        <div className="cta">
          <img src={Achievement} alt="Achievement" />
          <div className="cta__text-column">
            <h2>ICPC Asia-West Continent Final</h2>
            <div className="cta-col">
              <div className="section-col">
                <p>1) Astralix:</p>
                <p>Harman Kahlon</p>
                <p>Ankur Dua</p>
                <p>Anurag Singh</p>
              </div>
              <div className="section-col">
                <p>2) One_Last_Time:</p>
                <p>Srijan Jaiswal</p>
                <p>Kaleem Ahmad</p>
                <p>Sahil Anand</p>
              </div>
            </div>
          </div>
        </div>

        <div className="cta">
          <img src={Achievement} alt="Achievement" />
          <div className="cta__text-column">
            <h2>ICPC Regionals</h2>
            <div className="cta-column">
              <div className="section-col">
                <p>1) Astralix:</p>
                <p>(Kanpur, Gwalior)</p>
                <p>Harman Kahlon</p>
                <p>Ankur Dua</p>
                <p>Anurag Singh</p>
              </div>
              <div className="section-col">
                <p>2) Andhera_Kayam_Rahe:</p>
                <p>(Kharagpur, Amritapuri)</p>
                <p>Prashant Mittal</p>
                <p>Ayush Bansal</p>
                <p>Madhur Chauhan</p>
              </div>
              <div className="section-col">
                <p>3) Skullcandy:</p>
                <p>(Kanpur, Amritapuri)</p>
                <p>Vibhor Shukla</p>
                <p>Saksham Gupta</p>
                <p>Faizan Amjad</p>
              </div>
              <div className="section-col">
                <p>4) kangra308:</p>
                <p>(Gwalior, Amritapuri)</p>
                <p>Saurav Kumar</p>
                <p>Amit Singh</p>
                <p>Shubhanshu Chauhan</p>
              </div>
              <div className="section-col">
                <p>5) Mushroom Boys:</p>
                <p>(Amritapuri)</p>
                <p>Pawan Dogra</p>
                <p>Apurv Mayank</p>
                <p>Vishal Som</p>
              </div>
              <div className="section-col">
                <p>6) One_Last_Time:</p>
                <p>(Amritapuri)</p>
                <p>Srijan Jaiswal</p>
                <p>Kaleem Ahmad</p>
                <p>Sahil Anand</p>
              </div>
            </div>
          </div>
        </div>
        <div class="cta">
          <img src={AchievementFlipkart} alt="Achievement Flipkart" />
          <div className="cta__text-column">
            <h2>Flipkart Grid</h2>
            <div className="cta-coll">
              <div className="section-col">
                <p>No-Mo Team:</p>
                <p>Aman Deep Singh(ECE)</p>
                <p>Abhay Gaur(CSE)</p>
                <p>AdityaSharma(CSE)</p>
              </div>
            </div>
          </div>
        </div>

        <div class="cta">
          <img src={AchievementGoogle} alt="Achievement Google" />
          <div className="cta__text-column">
            <h2>Google Summer of Code (GSoC) -2020</h2>
            <div className="cta-coll">
              <div className="section-col">
                <p>1. Abhinav Bajpai (DD CSE)</p>
                <p>2. Naveen Jain (CSE)</p>
                <p>3. Rishabh Agarwal ( M&C)</p>
                <p>4. Dhrubojyoti Biswas (M&C)</p>
                <p>5. Rahul Katiyar (M.Tech CSE)</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </>
  );
}
